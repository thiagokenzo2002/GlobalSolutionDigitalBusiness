package br.com.fiap.model;




//import java.util.Calendar;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Setup {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String nome;
	private String datan;
	//private Calendar datan;
	private String cpf;
	private String rg;
	private String datac;
	//private Calendar datac;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	/*
	public Calendar getDatan() {
		return datan;
	}
	public void setDatan(Calendar datan) {
		this.datan = datan;
	}
	*/
	
	public String getDatan() {
		return datan;
	}
	public void setDatan(String datan) {
		this.datan = datan;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	public String getDatac() {
		return datac;
	}
	
	/*
	public Calendar getDatac() {
		return datac;
	}
	public void setDatac(Calendar datac) {
		this.datac = datac;
	}
	*/
	
	public void setDatac(String datac) {
		this.datac = datac;
	}
	@Override
	public String toString() {
		return "Setup [nome=" + nome + ", datan=" + datan + ", cpf=" + cpf + ", rg=" + rg + ", datac=" + datac + "]";
	}
	
	
	
	
	
}
